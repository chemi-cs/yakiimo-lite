# Installed by the rdkit-pypi Pyodide wheel build.
import sys as _sys

if _sys.platform == "emscripten":
    import importlib.abc as _importlib_abc
    import importlib.machinery as _importlib_machinery
    import importlib.util as _importlib_util
    import os as _os

    class _RDKitExtensionFinder(_importlib_abc.MetaPathFinder):
        def find_spec(self, fullname, path, target=None):
            if fullname.split(".", 1)[0] != "rdkit" or not path:
                return None
            module_name = fullname.rsplit(".", 1)[-1]
            candidate = _os.path.normpath(
                _os.path.join(
                    _os.path.dirname(__file__),
                    "..",
                    "rdkit.libs",
                    module_name + ".so.wasm",
                )
            )
            if not _os.path.exists(candidate):
                return None
            loader = _importlib_machinery.ExtensionFileLoader(fullname, candidate)
            return _importlib_util.spec_from_file_location(
                fullname, candidate, loader=loader
            )

    _sys.meta_path.insert(0, _RDKitExtensionFinder())

import logging
import sys

# Need to import rdBase to properly wrap exceptions
# otherwise they will leak memory
from . import rdBase

try:
  from .rdBase import rdkitVersion as __version__
except ImportError:
  __version__ = 'Unknown'
  raise

logger = logging.getLogger("rdkit")

# if we are running in a jupyter notebook, enable the extensions
try:
  kernel_name = get_ipython().__class__.__name__
  module_name = get_ipython().__class__.__module__

  if kernel_name == 'ZMQInteractiveShell' or module_name == 'google.colab._shell':
    logger.info("Enabling RDKit %s jupyter extensions" % __version__)
    from rdkit.Chem.Draw import IPythonConsole
    rdBase.LogToPythonStderr()
except Exception:
  pass

# Do logging setup at the end, so users can suppress the
# "enabling jupyter" message at the root logger.
log_handler = logging.StreamHandler(sys.stderr)
logger.addHandler(log_handler)
logger.setLevel(logging.WARN)
logger.propagate = False

# Uncomment this to use Python logging by default:
# rdBase.LogToPythonLogger()

#
#  Boost vector iterators are VERY slow, but indexing is quite fast
#   this wraps the iterators into a much faster version
#

class VectIter:
    def __init__(self, vect):
        self.vect = vect
        self.l = len(vect)
        self.pos = -1

    def __iter__(self):
        return self
    
    def __next__(self):
        self.pos += 1
        if self.pos < self.l:
            return self.vect[self.pos]
        else:
            raise StopIteration()

def __vect__iter__(vect):
    return VectIter(vect)

VECT_WRAPS = {'MatchTypeVect', 'UnsignedLong_Vect', 'VectSizeT', 'VectorOfStringVectors'}

for name, object in vars(rdBase).items():
  if name.startswith("_list") or name.startswith("_vect") or name in VECT_WRAPS:
    if hasattr(object, "__iter__"):
      object.__iter__ = __vect__iter__

